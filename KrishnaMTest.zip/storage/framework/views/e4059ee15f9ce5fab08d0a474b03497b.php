

<?php $__env->startSection('content_header'); ?>
    <div class="col-md-6 text-end">
        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-outline-primary">Back</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="col-6 text-start">
                <h5 class="card-title">User Information</h5>
            </div>
            <div class="col-6 text-end">
                <a href="<?php echo e(route('users.edit', auth()->user()->id)); ?>"  class="btn btn-primary">Update User</a>
            </div>
            

            <div id="profile_picture_preview" class="mt-2">
                <img src="<?php echo e(asset($user->profile_picture ?? 'https://via.placeholder.com/150')); ?>" alt="Profile Preview" class="img-fluid rounded-circle">
            </div>

            <dl class="row mt-3">
                <dt class="col-sm-3">First Name:</dt>
                <dd class="col-sm-9"><?php echo e($user->first_name); ?></dd>

                <dt class="col-sm-3">Last Name:</dt>
                <dd class="col-sm-9"><?php echo e($user->last_name); ?></dd>

                <dt class="col-sm-3">Email:</dt>
                <dd class="col-sm-9"><?php echo e($user->email); ?></dd>

                <dt class="col-sm-3">Phone:</dt>
                <dd class="col-sm-9"><?php echo e($user->phone); ?></dd>

                <dt class="col-sm-3">Gender:</dt>
                <dd class="col-sm-9"><?php echo e($user->gender); ?></dd>

                <dt class="col-sm-3">Role:</dt>
                <dd class="col-sm-9"><?php echo e($user->role); ?></dd>

                <dt class="col-sm-3">Addresses:</dt>
                <dd class="col-sm-9">
                    <?php $__empty_1 = true; $__currentLoopData = $user->addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="mb-2">
                            <strong>Address <?php echo e($index + 1); ?>:</strong><br>
                            <?php echo e($address->address_line); ?>, <?php echo e($address->city); ?>, <?php echo e($address->state); ?>, <?php echo e($address->country); ?> - <?php echo e($address->zip_code); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No addresses available.
                    <?php endif; ?>
                </dd>
            </dl>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Your existing JavaScript code -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['pageTitle' => 'User Details'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel_proj\mTestKrishnaPawar\resources\views/admin/users/userDetail.blade.php ENDPATH**/ ?>