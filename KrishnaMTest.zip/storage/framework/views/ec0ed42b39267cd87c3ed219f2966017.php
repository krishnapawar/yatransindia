<nav id="sidebarMenu" class="collapse d-lg-block sidebar collapse bg-white shadow-sm">
    <div class="position-sticky">
        <div class="list-group list-group-flush mx-3 mt-4">
            <a href="<?php echo e(route('home')); ?>"
                class="list-group-item list-group-item-action py-2 ripple <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>"
                aria-current="true">
                <i class="fas fa-tachometer-alt fa-fw me-3"></i><span>Main dashboard</span>
            </a>

            <a href="<?php echo e(route('profile')); ?>"
                class="list-group-item list-group-item-action py-2 ripple <?php echo e(request()->is('dashboard/profile*') ? 'active' : ''); ?>">
                <i class="fas fa-user fa-fw me-3"></i><span>Profile</span>
            </a>

            <a href="<?php echo e(route('users.index')); ?>"
                class="list-group-item list-group-item-action py-2 ripple <?php echo e(request()->is('dashboard/users*') ? 'active' : ''); ?>">
                <i class="fas fa-users fa-fw me-3"></i><span>Users</span>
            </a>
            <a class="list-group-item list-group-item-action py-2 ripple " href="<?php echo e(route('logout')); ?>"
                onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                <i class="fas fa-sign-out-alt fa-fw me-3"></i><span><?php echo e(__('Logout')); ?></span>

            </a>


        </div>
    </div>
</nav>

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
    <?php echo csrf_field(); ?>
</form>
<?php /**PATH C:\xampp\htdocs\laravel_proj\mTestKrishnaPawar\resources\views///admin/sidebare.blade.php ENDPATH**/ ?>